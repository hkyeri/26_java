package day04;
import java.util.Scanner;
public class Ex10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//무한반복해서 정수를 입력한 후, 음수가 입력되면 무한반복을 종료하고
		//누적의 합을 출
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("정수를 입력하세요.");
		int sum=0;
		while(true) {
			int num=scanner.nextInt();
			if(num<0)
				break;
			else {
				sum=sum+num;
			}
		}
		
		System.out.println("양수의 합은 "+sum);
		
	}

}
