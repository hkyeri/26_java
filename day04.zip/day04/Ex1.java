package day04;
import java.util.Scanner;
public class Ex1 {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("나이(만 나이)를 입력하시오: ");
		int age=scan.nextInt();
		
		if(age<18) {
			System.out.println("청소년 관람 불가");
		}
	}
}
