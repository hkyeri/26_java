package day04;

public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1부터 10까지 합을 계산하는 for 반복문 완성
		
		int sum=0;
		for(int i=1;i<=10;i++) {
			sum+=i;
		}
		System.out.println(sum);
	}

}
