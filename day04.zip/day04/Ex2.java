package day04;
import java.util.Scanner;
public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		System.out.println("필기시험 점수를 입력하시오: ");
		int score=scan.nextInt();
		System.out.println("토익 점수를 입력하시오: ");
		int num=scan.nextInt();
		
		if((score>=80)&&(num>850)) {
			System.out.println("합격");
		}
		else {
			System.out.println("불합격");
		}

	}

}
