package day04;

public class Gugudan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int dan=2; dan<10; dan++) {
			for(int j=1;j<10;j++) {
				System.out.println(dan+"*"+j+"="+dan*j);
				System.out.println('\t');
			}
			System.out.println();
		}
	}

}
