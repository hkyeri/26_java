package day04;
import java.util.Scanner;
public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		int balance=10000;
		System.out.println("나이(만 나이)를 입력하시오: ");
		int age=scan.nextInt();
		
		if((age>=7)&&(age<=12)) {
			System.out.println("잔액은 "+(balance-450)+"입니다.");
		}
		else if((age>=13)&&(age<=18)) {
			System.out.println("잔액은 "+(balance-720)+"입니다.");
		}
		else if((age>=19)) {
			System.out.println("잔액은 "+(balance-1200)+"입니다.");
		}

	}

}
