package day04;
import java.util.Scanner;
public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		System.out.println("가위, 바위, 보 게임입니다. 가위, 바위, 보 중에서 입력하세요.");
		String user1=scan.next();
		System.out.println("철수>>>"+user1);
		String user2=scan.next();
		System.out.println("영희>>>"+user2);
		
		if((user1.equals("보"))) {
			if(user2.equals("보")) {
				System.out.println("비겼습니다.");
			}
			else if(user2.equals("바위")) {
				System.out.println("철수가 이겼습니다.");
			}
			else {
				System.out.println("영희가 이겼습니다.");
			}
		}
		
		else if((user1.equals("가위"))) {
			if(user2.equals("가위")) {
				System.out.println("비겼습니다.");
			}
			else if(user2.equals("보")) {
				System.out.println("철수가 이겼습니다.");
			}
			else {
				System.out.println("영희가 이겼습니다.");
			}
		}
		
		else if((user1.equals("주먹"))) {
			if(user2.equals("주먹")) {
				System.out.println("비겼습니다.");
			}
			else if(user2.equals("가위")) {
				System.out.println("철수가 이겼습니다.");
			}
			else {
				System.out.println("영희가 이겼습니다.");
			}
		}
		
	
	}

}
