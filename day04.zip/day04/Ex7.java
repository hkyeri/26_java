package day04;

public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1부터 10까지의 합을 계산하는 while 반복문 완성
		
		int i=1; //초기식
		int sum=0;
		
//		while(i<=100) {
//			sum+=i;
//			i++;
//		}
//		System.out.println(sum);
		
		do {
			sum=sum+i;
			i++;
		}while(i<=100);
			
		System.out.println(sum);
	}

}
