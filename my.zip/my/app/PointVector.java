package my.app;
import java.util.Vector;

class Point{
	private int x, y;
	public Point(int x, int y) {
		this.x=x;
		this.y=y;
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x=x;
	}
	
	public int setY() {
		return y;
	}
	
	public int getY() {
		return y;
	}
	
	public String toString() {
		return "("+x+","+y+")";
	}
}

public class PointVector {

	public static void main(String[] args) {
		Vector<Point> v=new Vector<Point>();
		
		v.add(new Point(2,3));
		v.add(new Point(-5, 20));
		v.add(new Point(30,-8));
		
		for(int i=0; i<v.size();i++) {
			System.out.println(v.elementAt(i).getX());
			System.out.println(v.elementAt(i).getX());
		}
		
		for(Point p:v) {
			System.out.println(p.getX());
			System.out.println(p.getY());
		}

	}

}
