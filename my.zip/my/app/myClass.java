package my.app;
import java.util.Scanner;
import java.awt.Frame;

public class myClass {
	
	//Object object=new Object();
	
	String a;
	
	
	public String toString() {
		return a;
	}
	
	public static void main(String[] args) {
		
		myClass my=new myClass();
		my.a="문자열1";
		
		
		String b=new String("문자열2");
		System.out.println(my.toString());
		System.out.println(b);
		
		Frame f=new Frame();
		f.setSize(500,500);
		f.setVisible(true);
		
	}
}
