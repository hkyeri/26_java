package day09;

public class Student extends Human {
	private String sid;
	
	public Student(String name, int age, String sid) {
		super(name, age);
		this.sid=sid;
	}
	
	public String setSid(String sid) {
		this.sid=sid; 
	}
	
	public String getSid() {
		return sid;
	}
}
