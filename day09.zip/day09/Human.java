package day09;

public class Human extends Animal{

	private String addr;
	
	public Human(String name, int age) {
		super(name, age);
	}
	
	
	public String getAddr() {
		return addr;
	}
	
	public void setAddr(String addr) {
		this.addr=addr;
	}
	

}
