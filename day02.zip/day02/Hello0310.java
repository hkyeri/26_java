package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// print 계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력하
		
		System.out.println("프로그램 제작");
		System.out.print("1.아이디어 구상\n");
		System.out.print("2.코드 구상 및 제작\n");
		System.out.print("3.제작 프로그램 수정\n");
		
	}

}
