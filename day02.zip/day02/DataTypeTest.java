package day02;

public class DataTypeTest {
	
	public static void main(String[] args) {
		//1.기본형 변수 선
		boolean isTrue;
		int age;
		double height, weight;
		
		//2.레퍼런스 초기
		isTrue=false;
		age=21;
		height=165;
		weight=53;
		
		
		//2. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스)
		String name;
		name="박혜리";
		String s = new String("박혜리");
		
		DataTypeTest dtt = new DataTypeTest();
		//주소 addr
		String addr;
		addr="서울시 종로구";
		
		//3.변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);
		System.out.println("이름:"+name);
		System.out.println("주소:"+addr);
	}
}
