package day11;

public class SmartPhone extends Calc implements PhoneInterface{
	
	

	public static void main(String[] args) {
		SmartPhone sp=new SmartPhone();
		sp.sendCall();
		sp.receiveCall();
		System.out.println("3+5="+sp.calculate(3, 5));
		
	}

	@Override
	public void sendCall() {
		System.out.println("따르릉따르릉");
	}

	@Override
	public void receiveCall() {
		System.out.println("전화 왔어요");
	}

}
