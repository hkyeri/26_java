package day07;

//Circle
class Circle{
	int radius;
	String name;
	
	public Circle () { //기본 생성자
		this(0,"");
	}
	public Circle(int name) {
		this(name, "불고기 피자");
	}
	
	public Circle (int radius, String name) { //인자생성자
		this.radius=radius;
		this.name=name;
	}
	
	public double getArea() {
		return 3.14*radius*radius;
	}
}



public class Pizza {
	public static void main(String[] args) {
		//1. 레퍼런스 변수 pizza 선
		Circle pizza;
		//2. Circle 객체 생성 
		pizza=new Circle();
		pizza2=new Circle(10, "치즈피자");
		//3. 피자의 반지름을 10으로 설정
		//pizza.radius=10;
		//4. 피자의 이름을 불고기 피자로 설정
		//pizza.name="불고기 피자";
		//5. 피자의 면적 메소드 호출하여 알아내기
		double area=pizza.getArea();
		System.out.println(pizza.name+"의 면적은 "+area);
		
		Circle donut=new Circle();
		donut.radius=5;
		donut.name="자바도넛";
		area=donut.getArea();
		System.out.println(donut.name+"의 면적은 "+area);
	}

}
