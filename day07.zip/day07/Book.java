package day07;

class Library{
	String title;
	String writer;
	
	public Library() {
		/*
		 title="모순";
		 writer="양귀자";
		 */
	}
}

public class Book {

	public static void main(String[] args) {
		Library book;
		book=new Library();
		book.title="모순";
		book.writer="양귀자";
		
		System.out.println("책의 제목은 "+book.title+"입니다.");
		System.out.println("저자는 "+book.writer+"입니다.");

	}

}
