package day07;

public class Person {
		// 필드 (변수)
		public String name;
		public int age;
		public char abo;
		///////////////////////
		private String addr;
		///////////////////////
		
		//기본 생성자 정의: 클래스 이름과 동일한 메소드, 객체 생성 시 호출
		//역할: 필드(변수 초기화)
		public Person() {
			name="홍길동";
			age=21;
			abo='A';
			System.out.println("객체가 생성됨");
		}
		
		public static void getName(S) {
			return name;
		}
		
		//메소드
		public void 밥먹기() {
			System.out.println("밥먹다.");
		}
		
		public void 운동하기(String s) {
			System.out.println(s+"종목을 운동합니다.");
		}
	}

