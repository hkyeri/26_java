package day07;

public class Personex {
	public static void main(String[] args) {
		Person kim=new Person();
		kim.name="김민지";
		kim.age=20;
		kim.abo='O';
		kim.밥먹기();
		kim.운동하기("달리기");
	}
}
