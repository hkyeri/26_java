package day05;
import java.util.Scanner;
public class Array01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		
		int intArray[]=new int[5];
		int sum=0;
		
		int max=0;
		System.out.println(intArray.length+"개를 입력하세요>>>");
		for(int i=0; i<5; i++) {
			intArray[i]=scanner.nextInt();
			if(intArray[i]>max)
				max=intArray[i];
		}
		
		for(int i=0; i<5; i++) {
			sum+=intArray[i];
		}
		
		System.out.println("가장 큰 수 "+max+"입니다");
		System.out.println("평균은 "+(double)sum/intArray.length);
		
		scanner.close();
	}

}
