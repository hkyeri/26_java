package day06;
import java.util.Scanner;
public class Method2 {
	
	public static void max(){
		Scanner scan=new Scanner(System.in);
		System.out.println("첫번째 정수를 입력하시오: ");
		int a=scan.nextInt();
		System.out.println("두번째 정수를 입력하시오: ");
		int b=scan.nextInt();
		
		if(a>b)
			System.out.println("max="+a);
		else if(a<b)
			System.out.println("max="+b);
		else if(a==b) {
			System.out.println("두 수는 동일");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		max();
	}

}
