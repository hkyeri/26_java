package day06;
import java.util.Scanner;
public class Method3 {
	
	public static void add() {
		Scanner scan=new Scanner(System.in);
		System.out.println("첫번째 정수를 입력하시오: ");
		int a=scan.nextInt();
		System.out.println("두번째 정수를 입력하시오: ");
		int b=scan.nextInt();
		System.out.println("계산 문자를 입력하시오: ");
		String c=scan.next();
		
		if (c.equals("+"))
			System.out.println(a+b);
		else if(c.equals("-"))
			System.out.println(a-b);
		else if(c.equals("*"))
			System.out.println(a*b);
		else if(c.equals("/"))
			System.out.println(a/b);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		add();
	}

}
