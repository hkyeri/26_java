package day06;
import java.util.Scanner;
public class Add {
	 public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		
		double num1, num2, num3;
		
		System.out.print("첫 번째 정수 입력: ");
	    num1 = scanner.nextDouble();
	
	    System.out.print("두 번째 정수 입력: ");
	    num2 = scanner.nextDouble();
	
	    num3 = num1 * num2;
	    
	    System.out.println("곱: "+num3);
	 }
}
