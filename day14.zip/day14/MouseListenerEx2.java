package day14;
import javax.swing.*;
import day14.MouseListenerEx.MyMouseListener;
import java.awt.event.*;
import java.awt.*;


public class MouseListenerEx2 extends JFrame{
private JLabel la=new JLabel("Hello");
	
	public MouseListenerEx2() {
		setTitle("Mouse 이벤트 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c= getContentPane();
		c.addMouseListener(new MyMouseListener());
		
		c.setLayout(null);
		la.setSize(50,20);;
		la.setLocation(30,30);
		c.add(la);
		
		c.addMouseMotionListener(new MyMouseListener2());
		
		
		setSize(250, 250);
		setVisible(true);
	}
	
	class MyMouseListener2 extends MouseMotionAdapter{
		public void mouseDragged(MouseEvent e) {
			la.setText("MouseDragged("+e.getX()+","+e.getY()+")");

		}
		
		public void mouseMoved(MouseEvent e) {
			la.setText("MouseMoved("+e.getX()+","+e.getY()+")");
		}
	}
	
	class MyMouseListener implements MouseListener{

		@Override
		public void mouseClicked(MouseEvent e) {
		}

		@Override
		public void mousePressed(MouseEvent e) {
			int x=e.getX();
			int y=e.getY();
			Point p=new Point(x,y);
			la.setLocation(p);
			System.out.println(p);
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {	
		}

		@Override
		public void mouseEntered(MouseEvent e) {
		}

		@Override
		public void mouseExited(MouseEvent e) {	
		}
		
	}

	public static void main(String[] args) {
		new MouseListenerEx2();

	}

}
